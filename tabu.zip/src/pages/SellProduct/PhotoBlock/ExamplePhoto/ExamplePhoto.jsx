import * as S from "./Styled";

const ExamplePhoto = (props) => {
  return <S.ExamplePhoto {...props} alt="" />;
};

export default ExamplePhoto;
