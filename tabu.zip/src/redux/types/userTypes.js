export const SET_USER = "SET_USER";
export const LOGOUT = "LOGOUT";

export const SET_BUY_ITEMS = "SET_BUY_ITEMS";
export const SET_SELL_ITEMS = "SET_SELL_ITEMS";
export const SET_WISH_LIST = "SET_WISH_LIST";
