export const SHOW_MODAL = "SHOW_MODAL";
export const HIDE_MODAL = "HIDE_MODAL";
export const SET_PRODUCTS = "SET_PRODUCTS";
export const SET_OPENED_PRODUCT = "SET_OPENED_PRODUCT";
export const SET_SHARE_PRODUCT = "SET_SHARE_PRODUCT";
export const SET_SIZES = "SET_SIZES";
export const SET_NEW_PRODUCTS = "SET_NEW_PRODUCTS";
export const SET_TRENDS = "SET_TRENDS";
