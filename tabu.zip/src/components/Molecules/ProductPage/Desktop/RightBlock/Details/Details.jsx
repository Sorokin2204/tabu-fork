import * as S from "./Styled";

const Details = () => {
  return (
    <S.Container>
      <S.Title>ДЕТАЛИ ПРОДУКТА</S.Title>
      <S.List>
        <ul>
          <li>Lorem ipsum</li>
          <li>Lorem ipsum</li>
          <li>Lorem ipsum</li>
          <li>Lorem ipsum</li>
          <li>Lorem ipsum</li>
          <li>Lorem ipsum</li>
        </ul>
      </S.List>
    </S.Container>
  );
};

export default Details;
