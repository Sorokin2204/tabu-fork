import styled from "styled-components";

export const Container = styled.div`
  margin-top: 80px;
`;

export const Expands = styled.div`
  display: flex;
  flex-direction: column;
`;
