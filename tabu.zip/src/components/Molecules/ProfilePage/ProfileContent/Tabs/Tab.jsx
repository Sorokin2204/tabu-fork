import * as S from "./Styled";

const Tab = (props) => {
  return <S.Tab {...props}>{props.children}</S.Tab>;
};

export default Tab;
