import * as S from './Styled'

const MobileTopHeader = () => {
    return (
        <S.MobileTopHeader>
            Hовая и почти новая одежда
        </S.MobileTopHeader>
    );
};

export default MobileTopHeader;
