import React from "react";

const FavoriteIcon = () => {
  return (
    <svg
      width={20}
      height={18}
      viewBox="0 0 20 18"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M19 5.50003C19 11.7444 10.0004 17 10.0004 17C10.0004 17 1 11.6667 1 5.51268C1 3.00003 3 1.00003 5.5 1.00003C8 1.00003 10 4.00003 10 4.00003C10 4.00003 12 1.00003 14.5 1.00003C17 1.00003 19 3.00003 19 5.50003Z"
        stroke="#191919"
        strokeWidth="1.5"
        strokeLinecap="round"
      />
    </svg>
  );
};

export default FavoriteIcon;
