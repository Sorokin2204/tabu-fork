export const default_sizes = [{ name: "XS" }, { name: "S" }, { name: "M" }];
