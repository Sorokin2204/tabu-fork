export const sizes = {
    mobile: 1110
}

export const media = {
    mobile: `(max-width: ${sizes.mobile}px)`
}